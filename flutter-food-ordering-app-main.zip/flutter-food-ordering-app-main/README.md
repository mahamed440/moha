<img src="android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png" alt="icon" width="100"/>

# Food ordering app on Flutter

A sample Flutter application to show the menu of restaurants.

## Screenshots

![1](screenshots/screens.png) 

